<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
        <h1>Crear Estudiante</h1>
        <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="title" class="form-label">Titulo</label>
                <input type="text" class="form-control" id="title" name="title" required />
            </div>
            <div class="form-group mb-3">
                <label for="description" class="form-label">Descripcion</label>
                <input type="text" class="form-control" id="description" name="description" required />
            </div>
            <div class="form-group mb-3">
                <label for="points" class="form-label">Puntos</label>
                <input type="number" class="form-control" id="points" name="points" required />
            </div>
            <div class="form-group mb-3">
                <label for="direccion" class="form-label">Estado</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="nuevo">Nuevo</option>
                    <option value="seminuevo">Seminuevo</option>
                    <option value="usado">Usado</option>
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="foto" class="form-label">Categoria</label>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="categories[]" value="<?php echo e($categoria->id); ?>"
                            id="category<?php echo e($categoria->id); ?>">
                        <label class="form-check-label" for="category<?php echo e($categoria->id); ?>">
                            <?php echo e($categoria->name); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="form-group mb-3">
                <label for="foto" class="form-label">Imagen del producto</label>
                <input type="file" class="form-control" id="foto" name="foto" required />
            </div>
            <button type="submit" class="btn btn-primary" name="">Crear</button>
        </form>
    </div>
    <?php if (isset($component)) { $__componentOriginal677f03edb23dff14f06cecc48b460030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal677f03edb23dff14f06cecc48b460030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-link','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $attributes = $__attributesOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__attributesOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $component = $__componentOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__componentOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\2026-laravel-2eval-DaniCH20\resources\views/products/create.blade.php ENDPATH**/ ?>