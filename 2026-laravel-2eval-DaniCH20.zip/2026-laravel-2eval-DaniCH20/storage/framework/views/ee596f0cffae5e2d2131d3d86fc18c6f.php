<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>



    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
        <h1>Listado de productos</h1>

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <div>
                    <img onerror="this.onerror=null;this.src=`https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png?20200919003010`"
                        src="<?php echo e(asset($product->image)); ?>" width="80" height="80" class="rounded-circle">
                    <h2><?php echo e($product->title); ?></h2>
                    <h2><?php echo e($product->status); ?></h2>
                </div>
                <div>
                    <a class="btn btn-primary" href="<?php echo e(route('products.favorite', $product->id)); ?>">
                        <button class="btn" type="submit">❤️</button>
                    </a>
                    <a class="btn btn-primary" href="<?php echo e(route('products.show', $product->id)); ?>">
                        <button class="btn" type="submit">Ver detalles</button>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- Paginación simple  -->
    <?php if(!request()->has('search') && method_exists($products, 'links')): ?>
        <div class="pagination mt-3">
            <?php echo e($products->links('pagination::simple-bootstrap-4')); ?>

        </div>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal677f03edb23dff14f06cecc48b460030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal677f03edb23dff14f06cecc48b460030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-link','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $attributes = $__attributesOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__attributesOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $component = $__componentOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__componentOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\2026-laravel-2eval-DaniCH20\resources\views/home.blade.php ENDPATH**/ ?>