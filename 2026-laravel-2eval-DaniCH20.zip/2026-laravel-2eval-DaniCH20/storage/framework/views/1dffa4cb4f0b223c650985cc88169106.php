<div>
    <div>
        <img onerror="this.onerror=null;this.src=`https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png?20200919003010`"
            src="<?php echo e(asset('storage/imagenes/' . $product->image)); ?>" alt="asd" class="h-50 w-50">
        <h2><?php echo e($product->title); ?></h2>
        <br>
        <h3>Estado : <?php echo e($product->status); ?></h3>

    </div>
    <div>
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()): ?>
                <a class="btn btn-primary" href="<?php echo e(route('products.favorite', $product->id)); ?>">
                    <button class="btn" type="submit">❤️</button>
                </a>
            <?php else: ?>
                <a class="btn btn-primary" href="<?php echo e(route('products.unfavorite', $product->id)); ?>">
                    <button class="btn" type="submit">🩶</button>
                </a>
            <?php endif; ?>

        <?php endif; ?>
        <a class="p-4" href="<?php echo e(route('products.show', $product->id)); ?>">
            <button class="btn bg-blue-600 " type="submit">Ver detalles</button>
        </a>
    </div>
</div>
<?php /**PATH C:\laragon\www\2026-laravel-2eval-DaniCH20\resources\views/components/product-card.blade.php ENDPATH**/ ?>