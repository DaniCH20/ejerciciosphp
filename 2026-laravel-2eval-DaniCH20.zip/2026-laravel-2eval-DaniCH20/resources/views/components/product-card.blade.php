<div>
    <div>
        <img onerror="this.onerror=null;this.src=`https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png?20200919003010`"
            src="{{ asset('storage/imagenes/' . $product->image) }}" alt="asd" class="h-50 w-50">
        <h2>{{ $product->title }}</h2>
        <br>
        <h3>Estado : {{ $product->status }}</h3>

    </div>
    <div>
        @auth
            @if (auth()->user())
                <a class="btn btn-primary" href="{{ route('products.favorite', $product->id) }}">
                    <button class="btn" type="submit">❤️</button>
                </a>
            @else
                <a class="btn btn-primary" href="{{ route('products.unfavorite', $product->id) }}">
                    <button class="btn" type="submit">🩶</button>
                </a>
            @endif

        @endauth
        <a class="p-4" href="{{ route('products.show', $product->id) }}">
            <button class="btn bg-blue-600 " type="submit">Ver detalles</button>
        </a>
    </div>
</div>
