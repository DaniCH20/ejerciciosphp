@props(['active'])

@php

@endphp

<footer>
    <h3>Daniel Edgar Caballero Hurtado</h3>
</footer>
