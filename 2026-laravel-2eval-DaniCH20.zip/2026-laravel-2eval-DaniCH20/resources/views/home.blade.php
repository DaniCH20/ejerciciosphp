<x-app-layout>



    <div class="container">
        @yield('content')
        <h1>Listado de productos</h1>

        @foreach ($products as $product)
            <div>
                <div>
                    <img onerror="this.onerror=null;this.src=`https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png?20200919003010`"
                        src="{{ asset($product->image) }}" width="80" height="80" class="rounded-circle">
                    <h2>{{ $product->title }}</h2>
                    <h2>{{ $product->status }}</h2>
                </div>
                <div>
                    <a class="btn btn-primary" href="{{ route('products.favorite', $product->id) }}">
                        <button class="btn" type="submit">❤️</button>
                    </a>
                    <a class="btn btn-primary" href="{{ route('products.show', $product->id) }}">
                        <button class="btn" type="submit">Ver detalles</button>
                    </a>
                </div>
            </div>
        @endforeach
    </div>
    <!-- Paginación simple  -->
    @if (!request()->has('search') && method_exists($products, 'links'))
        <div class="pagination mt-3">
            {{ $products->links('pagination::simple-bootstrap-4') }}
        </div>
    @endif
    <x-footer-link>

    </x-footer-link>
</x-app-layout>
