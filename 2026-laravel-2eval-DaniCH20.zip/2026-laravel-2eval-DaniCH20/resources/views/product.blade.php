<x-app-layout>



    <div class="container">
        @yield('content')

        <h1>Listado de productos</h1>

        @foreach ($products as $product)
            <x-product-card :product="$product" />
        @endforeach

        @if (!request()->has('search') && method_exists($products, 'links'))
            <div class="pagination mt-3">
                {{ $products->links('pagination::simple-bootstrap-4') }}
            </div>
        @endif
    </div>
    <x-footer-link>

    </x-footer-link>
</x-app-layout>
