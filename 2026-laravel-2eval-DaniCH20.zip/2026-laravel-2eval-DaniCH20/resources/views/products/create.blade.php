<x-app-layout>


    <div class="container">
        @yield('content')
        <h1>Crear Estudiante</h1>
        <form action="{{ route('products.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group mb-3">
                <label for="title" class="form-label">Titulo</label>
                <input type="text" class="form-control" id="title" name="title" required />
            </div>
            <div class="form-group mb-3">
                <label for="description" class="form-label">Descripcion</label>
                <input type="text" class="form-control" id="description" name="description" required />
            </div>
            <div class="form-group mb-3">
                <label for="points" class="form-label">Puntos</label>
                <input type="number" class="form-control" id="points" name="points" required />
            </div>
            <div class="form-group mb-3">
                <label for="direccion" class="form-label">Estado</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="nuevo">Nuevo</option>
                    <option value="seminuevo">Seminuevo</option>
                    <option value="usado">Usado</option>
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="foto" class="form-label">Categoria</label>

                @foreach ($categories as $categoria)
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="categories[]" value="{{ $categoria->id }}"
                            id="category{{ $categoria->id }}">
                        <label class="form-check-label" for="category{{ $categoria->id }}">
                            {{ $categoria->name }}
                        </label>
                    </div>
                @endforeach
            </div>
            <div class="form-group mb-3">
                <label for="foto" class="form-label">Imagen del producto</label>
                <input type="file" class="form-control" id="foto" name="foto" required />
            </div>
            <button type="submit" class="btn btn-primary" name="">Crear</button>
        </form>
    </div>
    <x-footer-link>

    </x-footer-link>
</x-app-layout>
