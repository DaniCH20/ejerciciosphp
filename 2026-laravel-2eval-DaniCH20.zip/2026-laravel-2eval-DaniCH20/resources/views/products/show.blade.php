<x-app-layout>


    <div class="container">
        @yield('content')

        <table class="table table-striped">
            <thead>

                <tr>
                    <th colspan="2">Detalle del producto</th>
                </tr>
            </thead>

            <tbody>
                <tr>
                    <td>Titulo:</td>
                    <td>{{ $product->title }}</td>
                </tr>
                <tr>
                    <td>Descripcion: </td>
                    <td>{{ $product->description }}</td>
                </tr>
                <tr>
                    <td>Puntos: </td>
                    <td>{{ $product->points }}</td>
                </tr>
                <tr>
                    <td>Estado:</td>
                    <td> {{ $product->status }}</td>
                </tr>
                <tr>
                    <td>Foto:</td>
                    <td> <img
                            onerror="this.onerror=null;this.src=`https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png?20200919003010`"
                             src="{{ asset('storage/imagenes/' . $product->image)}}"width="80" height="80" class="rounded-circle"></td>
                </tr>
                <tr>
                    <td>Cursos Inscritos:</td>

                    @foreach ($categories as $categoria)
                        <td style="display: flex; align-items: center; gap: 5px;">

                            <label for="categoria-{{ $categoria->id }}">
                                {{ $categoria->name }}
                            </label>
                        </td>
                    @endforeach

                </tr>
                <tr>
                    <td>
                        <a class="btn btn-primary" href="{{ route('products.index') }}">
                            <button class="btn" type="submit">Volver al listado</button>
                        </a>
                    </td>
                    @auth
                        <td>
                            <a class="btn btn-primary" href="{{ route('products.favorite', $product->id) }}">
                                <button class="btn" type="submit">Asignar Favorito</button>
                            </a>
                        </td>
                    @endauth
                </tr>
            </tbody>
        </table>
    </div>
     <x-footer-link>

    </x-footer-link>
</x-app-layout>
