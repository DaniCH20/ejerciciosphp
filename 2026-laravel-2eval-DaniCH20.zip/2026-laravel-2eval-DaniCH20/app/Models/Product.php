<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\Factories\HasFactory;

class Product extends Model
{
    use HasFactory;
    protected $table = "products";
    protected $primaryKey = 'id';
    protected $fillable = [
        'title',
        'description',
        'points',
        'status',
        'image',
        'user_id'
    ];
    protected $guarded = ['id', 'created_at', 'updated_at'];

      // ✅ RELACIÓN: Un producto pertenece a UN usuario (dueño)
    public function owner()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    // ✅ RELACIÓN: Un producto puede ser favorito de MUCHOS usuarios
    public function favoritedBy()
    {
        return $this->belongsToMany(User::class, 'favorites')
                    ->withPivot('favorited_at')
                    ->withTimestamps();
    }

    // ✅ RELACIÓN: Un producto puede tener MUCHAS categorías
    public function categories()
    {
        return $this->belongsToMany(Category::class);
    }
}
