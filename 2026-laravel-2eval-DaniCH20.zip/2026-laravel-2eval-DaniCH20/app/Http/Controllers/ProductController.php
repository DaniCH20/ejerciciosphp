<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $products = Product::paginate(10);
        return view('product', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Product $products)
    {
        $categories = Category::all();
        return view('products.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'points' => 'required|integer',
            'status' => 'required|string|max:255',
            'categories' => 'array',
            'categories.*' => 'exists:categories,id',
            'foto' => 'nullable|image|max:2048',
        ]);

        // 1️⃣ Crear producto
        $product = Product::create([
            'title' => $request->title,
            'description' => $request->description,
            'points' => $request->points,
            'status' => $request->status,
            'user_id' => 1, // opcional si tiene dueño
        ]);

        // 2️⃣ Guardar imagen
        if ($request->hasFile('foto')) {
            $path = $request->file('foto')->store('imagenes', 'public');
            $product->image_url = $path;
            $product->save();
        }

        // 3️⃣ Guardar categorías en tabla pivot
        if ($request->has('categories')) {
            $product->categories()->attach($request->categories);
            // o sync()
        }

        return redirect()->route('products.index')->with('success', 'Producto creado correctamente');
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $product = Product::findOrFail($id);
        $categories = $product->categories;

        return view('products.show', compact('product', 'categories'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $product = Product::findOrFail($id);
        return view('products.edit', compact('product'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $product = Product::findOrFail($id);

        $product->update([
            'title' => $request->title,
            'description' => $request->description,
            'points' => $request->points,
            'status' => $request->status,
        ]);

        if ($request->hasFile('foto')) {
            $path = $request->file('foto')->store('imagenes', 'public');
            $product->image_url = $path;
            $product->save();
        }

        $product->categories()->sync($request->categories ?? []);

        return redirect()->route('products.index');
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $product = Product::findOrFail($id);
        $product->delete();
        return redirect()->route('products.index')->with('success', 'producto eliminado correctamente');
    }
    public function favorite(Product $product)
    {

        $user = auth()->user;

        $user->favorite()->attach($product->id, ['favorite_at' => now()]);
    }
    public function unfavorite(Product $product)
    {

        $user = auth()->user;
        $user->favorites()->detach($product->id);
    }
    public function misProductos()
    {
        $user = auth()->user;
    }
}
