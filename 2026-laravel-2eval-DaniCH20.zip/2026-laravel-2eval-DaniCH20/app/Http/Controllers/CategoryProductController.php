<?php

namespace App\Http\Controllers;

use App\Models\Category_Product;
use Illuminate\Http\Request;

class CategoryProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Category_Product $category_Product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Category_Product $category_Product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Category_Product $category_Product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Category_Product $category_Product)
    {
        //
    }
}
