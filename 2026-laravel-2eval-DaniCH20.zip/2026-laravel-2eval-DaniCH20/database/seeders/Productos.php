<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\User;
use App\Models\Category;

use Illuminate\Support\Carbon;

class Productos extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Obtener usuarios (asumiendo que ya están creados)


        // Crear productos EXACTAMENTE como en tu SQL
        $products = [
            [
                'title' => 'Portátil Gaming RTX 3060',
                'description' => 'Portátil para gaming con tarjeta RTX 3060 y 16GB RAM',
                'points' => 1200,
                'status' => 'nuevo',
                'image' => 'portatil_gaming_rtx3060.jpg',
                'user_id' => 1,
                'created_at' => Carbon::parse('2025-10-31 23:00:00'),
                'updated_at' => Carbon::parse('2025-10-31 23:00:00'),
            ],
            [
                'title' => 'Disco SSD 1TB',
                'description' => 'Unidad SSD de alta velocidad para almacenamiento rápido',
                'points' => 150,
                'status' => 'nuevo',
                'image' => 'disco_ssd_1tb.jpg',
                'user_id' => 2,
                'created_at' => Carbon::parse('2025-11-09 23:00:00'),
                'updated_at' => Carbon::parse('2025-11-09 23:00:00'),
            ],
            [
                'title' => 'El juego del alma',
                'description' => 'Novela contemporánea de misterio para jóvenes adultos',
                'points' => 18,
                'status' => 'nuevo',
                'image' => 'el_juego_del_alma.jpg',
                'user_id' => 1,
                'created_at' => Carbon::parse('2025-10-14 22:00:00'),
                'updated_at' => Carbon::parse('2025-10-14 22:00:00'),
            ],
            [
                'title' => 'Manual de desarrollo personal',
                'description' => 'Libro para mejorar habilidades y crecimiento personal',
                'points' => 22,
                'status' => 'nuevo',
                'image' => 'manual_desarrollo_personal.jpg',
                'user_id' => 2,
                'created_at' => Carbon::parse('2025-09-19 22:00:00'),
                'updated_at' => Carbon::parse('2025-09-19 22:00:00'),
            ],
            [
                'title' => 'FIFA 25',
                'description' => 'Última entrega del popular juego de fútbol',
                'points' => 60,
                'status' => 'nuevo',
                'image' => 'fifa_25.jpg',
                'user_id' => 3,
                'created_at' => Carbon::parse('2025-11-11 23:00:00'),
                'updated_at' => Carbon::parse('2025-11-11 23:00:00'),
            ],
            [
                'title' => 'Elden Ring',
                'description' => 'RPG de mundo abierto muy popular',
                'points' => 55,
                'status' => 'seminuevo',
                'image' => 'elden_ring.jpg',
                'user_id' => 1,
                'created_at' => Carbon::parse('2025-10-24 22:00:00'),
                'updated_at' => Carbon::parse('2025-10-24 22:00:00'),
            ],
            [
                'title' => 'Sudadera urbana',
                'description' => 'Sudadera con capucha marca juvenil',
                'points' => 40,
                'status' => 'nuevo',
                'image' => 'sudadera_urbana.jpg',
                'user_id' =>2,
                'created_at' => Carbon::parse('2025-11-04 23:00:00'),
                'updated_at' => Carbon::parse('2025-11-04 23:00:00'),
            ],
            [
                'title' => 'Camiseta Athletíc Club',
                'description' => 'Camiseta oficial temporada actual',
                'points' => 75,
                'status' => 'nuevo',
                'image' => 'camiseta_athletic_club_bilbao.jpg',
                'user_id' => 2,
                'created_at' => Carbon::parse('2025-11-14 23:00:00'),
                'updated_at' => Carbon::parse('2025-11-14 23:00:00'),
            ],
            [
                'title' => 'Pala de pádel profesional',
                'description' => 'Pala ligera y resistente para competición',
                'points' => 120,
                'status' => 'seminuevo',
                'image' => 'palapadel.jpg',
                'user_id' => 3,
                'created_at' => Carbon::parse('2025-11-09 23:00:00'),
                'updated_at' => Carbon::parse('2025-11-09 23:00:00'),
            ],
            [
                'title' => 'Tabla de surf',
                'description' => 'Tabla de surf para nivel intermedio',
                'points' => 300,
                'status' => 'usado',
                'image' => 'tabla_surf.jpg',
                'user_id' => 3,
                'created_at' => Carbon::parse('2025-10-29 23:00:00'),
                'updated_at' => Carbon::parse('2025-10-29 23:00:00'),
            ],
            [
                'title' => 'Tabla de padelsurf',
                'description' => 'Combinación de pádel y surf, novedad',
                'points' => 250,
                'status' => 'nuevo',
                'image' => 'tabla_padelsurf.jpg',
                'user_id' => 3,
                'created_at' => Carbon::parse('2025-11-10 23:00:00'),
                'updated_at' => Carbon::parse('2025-11-10 23:00:00'),
            ],
            [
                'title' => 'Microondas LG',
                'description' => 'Microondas digital con grill',
                'points' => 110,
                'status' => 'seminuevo',
                'image' => 'microondas_lg.jpg',
                'user_id' => 1,
                'created_at' => Carbon::parse('2025-11-01 23:00:00'),
                'updated_at' => Carbon::parse('2025-11-01 23:00:00'),
            ],
            [
                'title' => 'Lavadora Samsung 8kg',
                'description' => 'Lavadora eficiente con múltiples programas',
                'points' => 350,
                'status' => 'nuevo',
                'image' => 'lavadora_samsung_8kg.jpg',
                'user_id' =>4,
                'created_at' => Carbon::parse('2025-10-31 23:00:00'),
                'updated_at' => Carbon::parse('2025-10-31 23:00:00'),
            ],
            [
                'title' => 'El hostion que viene',
                'description' => 'Libro de IA',
                'points' => 15,
                'status' => 'seminuevo',
                'image' => '7e81R2GepciyG09VpsJMWBvLLSWKQWc3FvstMcu7.jpg',
                'user_id' => 2,
                'created_at' => Carbon::parse('2026-01-26 10:14:38'),
                'updated_at' => Carbon::parse('2026-01-26 10:14:39'),
            ],
            [
                'title' => 'Camiseta club de remo',
                'description' => 'Camiseta club de remo de Ondarroa',
                'points' => 23,
                'status' => 'usado',
                'image' => 'trIt9Ne2wHC6MVhtf5QP5i6A7eUkVtStf7esMzmO.jpg',
                'user_id' => 1,
                'created_at' => Carbon::parse('2026-01-29 17:50:23'),
                'updated_at' => Carbon::parse('2026-01-29 17:50:24'),
            ],
        ];

        foreach ($products as $productData) {
            Product::create($productData);
        }
    }
}
