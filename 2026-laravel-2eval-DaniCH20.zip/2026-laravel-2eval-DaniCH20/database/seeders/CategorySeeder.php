<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Category;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categoria = new Category();
        $categoria->name = 'Elektronica';
        $categoria->description = 'Componentes electrónicos';
        $categoria->save();

        $categoria = new Category();
        $categoria->name = 'Libros';
        $categoria->description = 'Libros y revistas';
        $categoria->save();

        $categoria = new Category();
        $categoria->name = 'Ropa';
        $categoria->description = 'Jantziak eta osagarriak';
        $categoria->save();

        $categoria = new Category();
        $categoria->name = 'Hogar';
        $categoria->description = 'Productos para casa';
        $categoria->save();

        $categoria = new Category();
        $categoria->name = 'Deporte';
        $categoria->description = 'Material deportivo';
        $categoria->save();
        $categoria = new Category();

        $categoria->name = 'Musica';
        $categoria->description = 'Instrumentos y discos';
        $categoria->save();
    }
}
