<footer>    
    <p>@ 2025 Refugio de animales</p>
    <p>Examen reto1 - Daniel Edgar Caballero Hurtado</p>
</footer>